Python 3.10.6 (tags/v3.10.6:9c7b4bd, Aug  1 2022, 21:53:49) [MSC v.1932 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
2
2
2+2
4
2+
SyntaxError: invalid syntax
'hello'
'hello'
'hello' + ' world'
'hello world'
ord('w')
119
ord('W')
87
chr(87)
'W'
chr(88)
'X'
bin(87)
'0b1010111'
