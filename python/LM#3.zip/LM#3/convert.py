fahrenheit_input= input('What is the temperature in Fahrenheit:')
fahrenheit_int= int(fahrenheit_input)
centigrade= (fahrenheit_int-32)/1.8
centigrade=round(centigrade)
print('The temperature is',centigrade,'in centigrade today')
