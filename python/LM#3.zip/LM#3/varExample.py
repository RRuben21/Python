
total=0
total
0
total=total+10
total
10
