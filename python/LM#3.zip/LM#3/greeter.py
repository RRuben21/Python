name= input('Enter your name please: ')
print('Hello',name)
