
customer_age_in_years=25
customer_name='Fred'
customer_age_in_years+customer_name
Traceback (most recent call last):
  File "<pyshell#2>", line 1, in <module>
    customer_age_in_years+customer_name
TypeError: unsupported operand type(s) for +: 'int' and 'str'
customer_age_in_years='Fred'
25
25
customer_age_in_years
'Fred'
message='the nameis'+customer_name
message='the name is' +customer_name
the name is
SyntaxError: invalid syntax
